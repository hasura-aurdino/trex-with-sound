//loadImage and addImage, is used when we have single image
//loadAnimation and addAnimation, is used when we have more than one image
var tRex;
var tRexImg;
var tRexColliedImg;

var ground,groundImg;

var invisableGround;

var obstacle1;
var obstacle2;
var obstacle3;
var obstacle4;
var obstacle5;
var obstacle6;

var gameRestartImg;
var gameOverImg;
var gameRestart;
var gameOver;

var play = 1;
var over = 0;
var gameState = 1;

var cloudsGroup;
var obstaclesGroup;

var score = 0;

function preload() {
  tRexImg = loadAnimation("trex1.png", "trex3.png", "trex4.png");
  tRexColliedImg = loadImage("trex_collided.png");
  groundImg = loadImage("ground2.png");
  cloudImg = loadImage("cloud.png");
  obstacle1 = loadImage("obstacle1.png");
  obstacle2 = loadImage("obstacle2.png");
  obstacle3 = loadImage("obstacle3.png");
  obstacle4 = loadImage("obstacle4.png");
  obstacle5 = loadImage("obstacle5.png");
  obstacle6 = loadImage("obstacle6.png");
  gameRestartImg = loadImage("restart.png");
  gameOverImg = loadImage("gameOver.png");
}

function setup() {
  createCanvas(900,400);
  tRex = createSprite(200,190,20,20);
  tRex.addAnimation("trexrunning", tRexImg);
  tRex.setCollider("circle", 0,0,20);
  tRex.debug = false;
  ground = createSprite(200,360,1200,20);
  ground.addImage("groundmoving", groundImg);
  invisableGround = createSprite(200,375,1200,20);
  invisableGround.visible = false;
  gameRestart = createSprite(500,250,20,20);
  gameRestart.addImage("restart",gameRestartImg);
  gameOver = createSprite(500,200);
  gameOver.addImage("over",gameOverImg);
  gameOver.scale = 3;
  cloudsGroup = new Group();
  obstaclesGroup = new Group();
}
//concatination
//console.log("apple" + "book");

//console.log("2" + 2);

//console.log(2 + 2);
function draw() {

  background("white");

  //distrubute the codes between the codes play and the end state
  if (gameState==0) {
    gameRestart.visible = true;
    gameOver.visible = true;
  ground.velocityX = 0;
  tRex.velocityY = 0;
  cloudsGroup.setVelocityXEach(0);
  obstaclesGroup.setVelocityXEach(0);
  tRex.addAnimation("trexcollied", tRexColliedImg);
  tRex.changeAnimation("trexcollied");
  gameOver.visible = true;
  gameRestart.visible = true;
  }

  if (gameState==1) {

    score = score + Math.round(getFrameRate()/60);

    gameRestart.visible = false;
    gameOver.visible = false;
    if (keyDown("space")&&tRex.y >= 344) {

      tRex.velocityY -= 15;
    }
  ground.velocityX = -5;
  if (ground.x < 0) {
    //ground.x = 900;
    ground.x = ground.width/2;
  }


  clouds();
  obstacles();

  if (obstaclesGroup.isTouching(tRex)) {

    gameState=0;

  }
  tRex.velocityY += 0.8;

  }

  tRex.collide(invisableGround);
  drawSprites();
  if (mousePressedOver(gameRestart)) {
    reset();
  }
  text("Score =" + score, 10,60);
}

function reset() {
  gameState = 1;
  obstaclesGroup.destroyEach();
  cloudsGroup.destroyEach();
  tRex.changeAnimation("trexrunning");
  gameRestart.visible = false;
  gameOver.visible = false;
  score = 0;
}

function clouds() {
  if (frameCount%120==0) {
    var cloud = createSprite(950,random(20,180));
    cloud.velocityX = -3;
    cloud.addImage("clouds", cloudImg);
    cloudsGroup.add(cloud);
    cloud.lifetime = 325;
  }
}

function obstacles() {
  if (frameCount%120==0) {
    var obstacle = createSprite(900,350);
    obstacle.velocityX = -5;
    obstacle.scale = 0.60;
    obstaclesGroup.add(obstacle);
    obstacle.depth = tRex.depth;
    tRex.depth += 1;
    //obstacle.addImage("obstacles", obstacleImg);
    var a = Math.round(random(1,6))
    switch(a) {
      case 1:
        obstacle.addImage("obstacle1", obstacle1);
        obstacle.scale = 0.60;
        break;
      
      case 2:
        obstacle.addImage("obstacle2", obstacle2);

    obstacle.scale = 0.10;
        break;

      case 3:
        obstacle.addImage("obstacle3", obstacle3);

    obstacle.scale = 0.10;
        break;

      case 4:
        obstacle.addImage("obstacle4", obstacle4);

    obstacle.scale = 0.10;
        break;

      case 5:
        obstacle.addImage("obstacle5", obstacle5);

    obstacle.scale = 0.10;
        break;

      case 6:
        obstacle.addImage("obstacle6", obstacle6);

    obstacle.scale = 0.10;
        break;

      default:
        break;
    }
  }
    
}